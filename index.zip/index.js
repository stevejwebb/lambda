'use static';
exports.handler = (event) => {
console.log('hello world!');
};
